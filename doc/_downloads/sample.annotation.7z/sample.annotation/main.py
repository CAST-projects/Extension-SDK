import cast.analysers
import cast.analysers.log
import cast.analysers.dotnet
import cast.analysers.external_link
import cast.analysers.filter

def link_to_table(type_,table_name):

    # search all tables or views with table_name as name
    tables = cast.analysers.external_link.find_objects(table_name,cast.analysers.filter.tables_or_views)
    
    # the position of the link will be the position of the class
    position = type_.get_position()
    for table in tables:
        cast.analysers.create_link('useLink',type_,table,position)
    
    
class Extension(cast.analysers.dotnet.Extension):
    """
    Handle links from classes to tables with System.Data.Linq.Mapping.TableAttribute
    """

    def __init__(self,plugin):
        self.plugin = plugin

    def start_type(self,type_):
        """
        @type type_: cast.analysers.Type
        """
        
        for annotation in type_.get_annotations():

            annotationType = annotation[0]

            if annotationType.get_fullname() == 'System.Data.Linq.Mapping.TableAttribute':
                parameters = annotation[1]

                if 'Name' in parameters:
                    table_name = parameters['Name']
                else:
                    table_name = type_.get_name()
                    # need also to respect conventions : plurals or not plurals on table name
                
                link_to_table(type_,table_name)

            
class SampleAnnotation(cast.analysers.Plugin):
    
    def __init__(self):
        cast.analysers.Plugin.__init__(self)
        self.register_extension(Extension(self))
