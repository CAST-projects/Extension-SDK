import cast
import cast.log
import cast.jee
import subprocess

def run_jslint(source_path, dir_path):
    """
    run jslint on source_path
    dir_path is a directory containing node.exe and jslint
    
    return a list of triplet : line, column, issue text
    
    """
    command = dir_path +'/node.exe -i ' + dir_path + '/jslintnode.js ' + source_path 
    cast.log.debug(command)
    p = subprocess.Popen(command,universal_newlines=True,stdout=subprocess.PIPE)
    (out,_) = p.communicate()
    problems = out.splitlines()
    
    result = []
    
    for element in problems:
        ''' @type: element : str'''
        structure = element.split(':')
        if len(structure) == 3:
            result.append([int(structure[0]),int(structure[1]),structure[2]])
        
    cast.log.debug(str(result))
    cast.log.debug(str(p.returncode))
    return result


def decode_jslint_issue(message):
    """ 
    Decode a jslint message and return either None or the rule (property) associated with the message
    """
    
    if message.startswith('Expected exactly one'):
        return 'JSLint_Violations.Expected_exactly_one_space'
    
    return None
    

class MyExtension(cast.jee.Extension):
    """Launch JSLint on javascript files"""

    def __init__(self,plugin):
        self.binary_path = plugin.get_plugin_directory() + '/bin'
        
    def end_web_file(self,file):
        source_path = file.get_path()
        cast.log.debug(str(source_path))

        # only consider javascript files
        if not source_path.endswith('.js'):
            return
        
        jslint_violations = run_jslint(source_path,self.binary_path)
        
        for violation in jslint_violations:
            
            rule = decode_jslint_issue(violation[2])
            
            if rule:
                bookmark = cast.Bookmark(file, violation[0], violation[1], violation[0], violation[1]+1)
                file.save_violation(rule,bookmark)
                
            
class JSLint(cast.Plugin):
    
    def __init__(self):
        cast.Plugin.__init__(self, 'com.castsoftware.jslint')
        self.register_extension(MyExtension(self))
