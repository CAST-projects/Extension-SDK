create or replace function  SET_JavascriptFunctions  (I_SET_ID int)
returns int
as
$body$
declare
ERRORCODE	INT := 0;
begin
/*<<NAME>>SET_JavascriptFunctions <</NAME>>*/
/*<<COMMENT>> Template name   = OBJSET. <</COMMENT>>*/
/*<<COMMENT>> Definition      =  Javascript functions. <</COMMENT>>*/

   
 
  insert into SET_Contents 
        (SetId, ObjectId)
  select distinct I_SET_ID, sql.OBJECT_ID
    from CTT_OBJECT_APPLICATIONS sql  
    
 where sql.OBJECT_TYPE  in ( 137746 )  -- javascript functions

    ;
	
Return ERRORCODE;
END;
$body$
LANGUAGE plpgsql
/
