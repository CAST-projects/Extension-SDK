var f = function() { return 8;};

var a = (function() { return 2;})() ;

document.write(a);
