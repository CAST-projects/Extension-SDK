import unittest
import cast.analysers.test

class Test(unittest.TestCase):

    def test_check_inheritance_link(self):
        # create a DotNet analysis
        analysis = cast.analysers.test.JEETestAnalysis()
        
        analysis.add_selection('test1')
        analysis.set_root_path('test1')
        analysis.set_verbose()
        analysis.run()

        
if __name__ == "__main__":
    unittest.main()