import cast.analysers.dotnet
import cast.analysers.log

class MyExtension(cast.analysers.dotnet.Extension):

    def start_analysis(self,options):
        cast.analysers.log.debug('Hello World!!')
        
class MyPlugin(cast.analysers.Plugin):

    def __init__(self):
        cast.analysers.Plugin.__init__(self)
        self.register_extension(MyExtension())

